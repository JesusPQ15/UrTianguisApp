package pe.edu.pe.tf.dtos;

public class Tipo_PrendaDTO {
    private int Id_tipo_prenda;
    private String Tipo_prenda;

    public int getId_tipo_prenda() {
        return Id_tipo_prenda;
    }

    public void setId_tipo_prenda(int idTipo_Prenda) {
        Id_tipo_prenda = idTipo_Prenda;
    }

    public String getTipo_prenda() {
        return Tipo_prenda;
    }

    public void setTipo_prenda(String tipo_prenda) {
        Tipo_prenda = tipo_prenda;
    }
}
