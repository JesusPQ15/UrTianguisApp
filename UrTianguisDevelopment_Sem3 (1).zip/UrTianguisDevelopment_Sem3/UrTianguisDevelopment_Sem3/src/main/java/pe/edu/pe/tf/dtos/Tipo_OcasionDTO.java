package pe.edu.pe.tf.dtos;

import jakarta.persistence.Column;

public class Tipo_OcasionDTO {

    private int id_tipo_ocasion;
    private String Tipo_ocasion;

}
