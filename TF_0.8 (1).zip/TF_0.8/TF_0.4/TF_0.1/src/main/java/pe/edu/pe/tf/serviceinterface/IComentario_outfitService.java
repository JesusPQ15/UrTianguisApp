package pe.edu.pe.tf.serviceinterface;

import pe.edu.pe.tf.entities.Comentario_outfit;

import java.util.List;

public interface IComentario_outfitService {
    public List<Comentario_outfit>list();
    public void insert(Comentario_outfit com);
}
