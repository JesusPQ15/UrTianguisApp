package pe.edu.pe.tf.controllers;

public class CatalogoController {
}
