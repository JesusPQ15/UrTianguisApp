package pe.edu.pe.tf.serviceimplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.pe.tf.entities.Outfit;
import pe.edu.pe.tf.repositories.IOutfitRepository;
import pe.edu.pe.tf.serviceinterface.IOutfitService;

import java.util.List;

@Service
 public class OutfitServiceImplement implements IOutfitService{

    @Autowired
    private IOutfitRepository oR;

    @Override
    public List<Outfit> list() {return oR.findAll();}

    @Override
    public void insertar(Outfit o) {
        oR.save(o);
    }

    @Override
    public void update(Outfit o) {
        oR.save(o);
    }

    @Override
    public void eliminar(int id) {
        oR.deleteById(id);
    }
 }
