package pe.edu.pe.tf.serviceinterface;

import org.springframework.data.repository.query.Param;
import pe.edu.pe.tf.entities.Usuario;

import java.util.List;

public interface IUsuarioService {
    public List<Usuario> list();

    public void insert(Usuario u);
    public void update(Usuario u);
    public void delete(int id);
    public String mesMenosUsuarios();

}
